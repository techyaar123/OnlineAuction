import { MinDirective } from './min.directive';

describe('MinDirective', () => {
  it('should create an instance', () => {
    const directive = new MinDirective();
    expect(directive).toBeTruthy();
  });
});
